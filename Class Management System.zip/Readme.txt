npm install nodemon
npm install express
npm install mongoose
npm install dotenv
